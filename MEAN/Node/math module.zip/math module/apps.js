var mathlib = require('./mathlib');
mathlib.add(1,2);
mathlib.multiply(2,6);
mathlib.square(4);
mathlib.random(1,10);
mathlib.random(40,50)